﻿namespace P01_StudentSystem
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server = DESKTOP-FPETI1U\SQLEXPRESS; Integrated Security = True; Database = StudentSystem";
    }
}