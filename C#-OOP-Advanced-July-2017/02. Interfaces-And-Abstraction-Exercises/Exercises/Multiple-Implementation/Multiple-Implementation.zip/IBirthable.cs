﻿// ReSharper disable once CheckNamespace
public interface IBirthable
{
    string Birthdate { get; }
}