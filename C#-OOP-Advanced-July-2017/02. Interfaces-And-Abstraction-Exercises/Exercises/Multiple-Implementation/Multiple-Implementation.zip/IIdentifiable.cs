﻿// ReSharper disable once CheckNamespace
public interface IIdentifiable
{
    string Id { get; }
}