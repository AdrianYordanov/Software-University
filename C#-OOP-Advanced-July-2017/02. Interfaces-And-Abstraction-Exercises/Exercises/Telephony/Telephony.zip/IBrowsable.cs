﻿public interface IBrowsable
{
    string Browse();
}