﻿namespace Black_Wars_New_Factory.Contracts
{
    public interface IUnit : IDestroyable, IAttacker
    {
    }
}