﻿namespace Black_Wars_New_Factory.Contracts
{
    public interface IDestroyable
    {
        int Health
        {
            get;
            set;
        }
    }
}