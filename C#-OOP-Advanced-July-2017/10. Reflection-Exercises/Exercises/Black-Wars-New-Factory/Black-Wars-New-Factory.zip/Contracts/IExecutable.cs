﻿namespace Black_Wars_New_Factory.Contracts
{
    public interface IExecutable
    {
        string Execute();
    }
}