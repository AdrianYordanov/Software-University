﻿namespace Black_Wars_New_Factory.Contracts
{
    public interface IAttacker
    {
        int AttackDamage
        {
            get;
        }
    }
}